// Copyright Epic Games, Inc. All Rights Reserved.

#include "WaterBrushCacheContainer.h"

UWaterBodyBrushCacheContainer::UWaterBodyBrushCacheContainer(const FObjectInitializer& ObjectInitializer) :
	Super(ObjectInitializer)
{ }
